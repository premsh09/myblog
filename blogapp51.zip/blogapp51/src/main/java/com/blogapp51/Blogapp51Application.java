package com.blogapp51;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Blogapp51Application {

	public static void main(String[] args) {
		SpringApplication.run(Blogapp51Application.class, args);
	}

}
